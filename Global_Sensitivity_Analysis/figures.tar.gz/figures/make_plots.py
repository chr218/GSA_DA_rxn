# -*- coding: utf-8 -*-
"""
Created on Tue Jan 25 12:56:52 2022

The purpose of this script is to plot
the Sobol indices outputted from "GSA_using_CSV.py".

@author: chr218
"""

import numpy as np
import matplotlib.pyplot as plt
import sys

nvar = 17

lim_s = 0.03

#Labels
#labs = [r'$C_{7}^{\ddag}$',r'$C_{P1}^{\ddag}$',r'$C_{P2}^{\ddag}$',r'$C_{M1}^{\ddag}$',
        #r'$C_{M2}^{\ddag}$',r'$C_{7}^{\ddag*}$',r'$C_{P1}^{\ddag}$',r'$C_{P2}^{\ddag}$',r'$C_{M1}^{\ddag}$',
        #r'$C_{M2}^{\ddag}$',r'$I_{C4}$',r'$I_{C5}$',r'$I_{7}$',r'$I_{P1}$',r'$I_{P2}$',r'$I_{M1}$',r'$I_{M2}$']

labs = [r'$R_{7}^{DA}$',r'$R_{P1}^{DA}$',r'$R_{P2}^{DA}$',r'$R_{M1}^{DA}$',r'$R_{M2}^{DA}$',
        r'$R_{7}^{ads}$',r'$R_{P1}^{ads}$',r'$R_{P2}^{ads}$',r'$R_{M1}^{ads}$',r'$R_{M2}^{ads}$',
        r'$I_{C2}$',r'$I_{C5}$',r'$I_{7}$',r'$I_{P1}$',r'$I_{P2}$',r'$I_{M1}$',r'$I_{M2}$']

#%%
#Collect Dat

f = open('slurm-7.5.out', "r")
lines_list = []
for line in f:
    lines_list.append(line.strip())

SU_list = []
SU_index_list = []

HEATMAP_val_list = []
HEATMAP_indices_list = []
Si_list = []
Si_T_list = []

for line in lines_list:
    split_line = line.split()
    if split_line[0] == 'SU':
        if len(split_line) > 3:
            HEATMAP_indices_list.append([split_line[1],split_line[2]])
            HEATMAP_val_list.append(float(split_line[-1]))
        else:
            SU_index_list.append(float(split_line[1]))
            SU_list.append(float(split_line[-1]))
    elif split_line[0].isdigit():
        Si_list.append(float(split_line[1]))
        Si_T_list.append(float(split_line[2]))
  

#%%
#Plot Sobol HeatMap
       
sobol_ij = np.zeros([nvar, nvar])
for i,indx in enumerate(HEATMAP_indices_list):
    sobol_ij[int(indx[0].strip(',')),int(indx[1])] = HEATMAP_val_list[i]
    sobol_ij[int(indx[1]),int(indx[0].strip(','))] = HEATMAP_val_list[i]

for i in range(nvar):
    sobol_ij[i, i] = 0

# viz second order of SA indices
fig = plt.figure(dpi=300)
ax = fig.gca()
#im = ax.imshow(sobol_ij, cmap='GnBu') #Uncomment this for auto-fit.
im = ax.imshow(sobol_ij, cmap='GnBu', vmin = 0.0, vmax = lim_s)

x = np.arange(nvar)
for i in range(nvar):
    ax.plot([-0.5, nvar - 0.5], [i + 0.5, i + 0.5], 'k:', lw=0.5)
    ax.plot([i + 0.5, i + 0.5], [-0.5, nvar - 0.5], 'k:', lw=0.5)
ax.plot([-0.5, nvar - 0.5], [-0.5, nvar - 0.5], 'k-', lw=0.8)
ax.set_xlim([-0.5, nvar - 0.5])
ax.set_ylim([nvar - 0.5, -0.5])
ax.tick_params(which='both', direction='in')
ax.set_xticks(x)
ax.set_xticklabels(labs,fontsize=5)
ax.set_yticks(x)
ax.set_yticklabels(labs,fontsize=5)
fig.colorbar(im)
#fig.savefig('HeatMap.png')
plt.show()
#%%
#Plot Sobol Indices

x = np.arange(nvar)
width = 0.4

sobol_i = Si_list
soboltol_i = Si_T_list

fig = plt.figure(figsize=(5, 2), dpi=200)
ax = fig.gca()
ax.bar(x - width / 2., sobol_i, width, label=r'S$_i$',color='bisque')
ax.bar(x + width / 2., soboltol_i, width, label=r'S$^T_i$',color='gold')
for i in range(nvar + 1):
    #ax.plot([i - 0.5, i - 0.5], [0, 1.1 * max(soboltol_i)], 'k--', lw=0.4)
    ax.plot([i - 0.5, i - 0.5], [0, 0.4], 'k--', lw=0.4)
ax.set_ylim([0, 0.4])#ylim based on MAX of perturbations up to 5.0 [kJ/mol]
#ax.set_ylim([0, 1.1 * max(soboltol_i)])
ax.tick_params(which='both', direction='in')
ax.set_xticks(x)
#ax.set_xticklabels(['%d' % (i + 1) for i in x])
ax.set_xticklabels(labs,fontsize=7)
#ax.set_xticklabels([])

plt.legend(frameon=False, fontsize=10, loc='best')
ax.set_ylabel('Sobol Index')
plt.show()
#fig.savefig('Sobol.png')
