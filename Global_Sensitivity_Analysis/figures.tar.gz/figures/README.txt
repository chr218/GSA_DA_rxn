This directory contains the calculated Sobol indices
from the microkinetic model (MKM) of the [4+2] Diels
Alder reactions between ethene and isoprene.

Files "slurm-0.05.out" etc. are the output from the 
ANOVA-based Global Sensitivity Analysis (GSA) code,
namely:

1) Logarithm of determinant of Information Matrix
2) Rank of Information Matrix
3) RMSE of the PCE fit.
4) Sobol indices (individual and Total)

The file "make_plots.py" shows how to plot the Sobol
indices into:

1) A bar plot showing the individual and total contributions of the Sobol indices.
2) A heatmap showing the correlations of reaction steps/intermediates per the mutual
contributions of the Sobol indices.